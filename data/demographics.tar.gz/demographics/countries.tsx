export const countries = [
    {
        "countryID": 1,
        "countryName": "Wildlands"
    },
    {
        "countryID": 2,
        "countryName": "Underground"
    },
    {
        "countryID": 3,
        "countryName": "Etrand"
    },
    {
        "countryID": 4,
        "countryName": "Etrancoast"
    },
    {
        "countryID": 5,
        "countryName": "Froturn"
    },
    {
        "countryID": 6,
        "countryName": "Dragoc"
    },
    {
        "countryID": 7,
        "countryName": "Artaburro"
    },
    {
        "countryID": 8,
        "countryName": "Neressa"
    },
    {
        "countryID": 9,
        "countryName": "Brutang"
    },
    {
        "countryID": 10,
        "countryName": "Keldorn"
    },
    {
        "countryID": 11,
        "countryName": "Gabyr"
    },
    {
        "countryID": 12,
        "countryName": "Shár"
    },
    {
        "countryID": 13,
        "countryName": "Týrýng"
    },
    {
        "countryID": 14,
        "countryName": "Shíd"
    },
    {
        "countryID": 15,
        "countryName": "Antanath"
    }
]