export const occupations = [
    {
        "occupationID": 1,
        "occupationName": "Unemployed"
    },
    {
        "occupationID": 2,
        "occupationName": "Students"
    },
    {
        "occupationID": 3,
        "occupationName": "Farmers"
    },
    {
        "occupationID": 4,
        "occupationName": "Labourers"
    },
    {
        "occupationID": 5,
        "occupationName": "Slaves"
    },
    {
        "occupationID": 6,
        "occupationName": "Craftsmen"
    },
    {
        "occupationID": 7,
        "occupationName": "Artisans"
    },
    {
        "occupationID": 8,
        "occupationName": "Servicemen"
    },
    {
        "occupationID": 9,
        "occupationName": "Entertainers"
    },
    {
        "occupationID": 10,
        "occupationName": "Bureaucrats"
    },
    {
        "occupationID": 11,
        "occupationName": "Intellctuals"
    },
    {
        "occupationID": 12,
        "occupationName": "Clergymen"
    },
    {
        "occupationID": 13,
        "occupationName": "Soldiers"
    },
    {
        "occupationID": 14,
        "occupationName": "Nobles"
    },
    {
        "occupationID": 15,
        "occupationName": "Merchants"
    },
    {
        "occupationID": 16,
        "occupationName": "Criminals"
    }
]