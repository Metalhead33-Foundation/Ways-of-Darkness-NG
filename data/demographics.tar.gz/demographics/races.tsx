export const races = [
    {
        "raceID": 1,
        "raceName": "Proto-Elf",
        "raceName_hun": "Őself"
    },
    {
        "raceID": 2,
        "raceName": "High Elf",
        "raceName_hun": "Nemeself"
    },
    {
        "raceID": 3,
        "raceName": "Wood Elf",
        "raceName_hun": "Erdőelf"
    },
    {
        "raceID": 4,
        "raceName": "Dark Elf",
        "raceName_hun": "Sötételf"
    },
    {
        "raceID": 5,
        "raceName": "Half-Elf",
        "raceName_hun": "Félelf"
    },
    {
        "raceID": 6,
        "raceName": "Human",
        "raceName_hun": "Ember"
    },
    {
        "raceID": 7,
        "raceName": "Orc",
        "raceName_hun": "Ork"
    },
    {
        "raceID": 8,
        "raceName": "Half-Orc",
        "raceName_hun": "Félork"
    },
    {
        "raceID": 9,
        "raceName": "Massenpreost Despotanfras",
        "raceName_hun": "Massenpreost Despotanfras"
    },
    {
        "raceID": 10,
        "raceName": "Lizardman",
        "raceName_hun": "Gyíkember"
    },
    {
        "raceID": 11,
        "raceName": "Dwarf",
        "raceName_hun": "Törp"
    },
    {
        "raceID": 12,
        "raceName": "Gnome",
        "raceName_hun": "Gnóm"
    },
    {
        "raceID": 13,
        "raceName": "Halfling",
        "raceName_hun": "Félszerzet"
    },
    {
        "raceID": 14,
        "raceName": "Goblin",
        "raceName_hun": "Goblin"
    },
    {
        "raceID": 15,
        "raceName": "Ogre",
        "raceName_hun": "Ogre"
    },
    {
        "raceID": 16,
        "raceName": "Dragon",
        "raceName_hun": "Sárkány"
    },
    {
        "raceID": 17,
        "raceName": "Nereid",
        "raceName_hun": "Nereid"
    },
    {
        "raceID": 18,
        "raceName": "Aeséni",
        "raceName_hun": "Aeséni"
    },
    {
        "raceID": 19,
        "raceName": "Winged Cobra",
        "raceName_hun": "Szárnyas kobra"
    },
    {
        "raceID": 20,
        "raceName": "Demon",
        "raceName_hun": "Démon"
    },
    {
        "raceID": 21,
        "raceName": "Angel",
        "raceName_hun": "Angyal"
    },
    {
        "raceID": 22,
        "raceName": "Limjiang",
        "raceName_hun": "Limjiang"
    },
    {
        "raceID": 23,
        "raceName": "Týrýng"
    },
    {
        "raceID": 24,
        "raceName": "Azisiri"
    },
    {
        "raceID": 25,
        "raceName": "Shíd"
    }
]