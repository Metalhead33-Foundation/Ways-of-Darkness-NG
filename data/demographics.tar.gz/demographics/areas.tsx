import {regions} from "./regions";

export const areas = [
    {
        "areaID": 1,
        "areaName": "Hro'z",
        "regionID": 1,
        "rural": false
    },
    {
        "areaID": 2,
        "areaName": "Kro'm",
        "regionID": 2,
        "rural": false
    },
    {
        "areaID": 3,
        "areaName": "Bru'k",
        "regionID": 3,
        "rural": false
    },
    {
        "areaID": 4,
        "areaName": "Pri'd",
        "regionID": 4,
        "rural": false
    },
    {
        "areaID": 5,
        "areaName": "Dhaeraow Loomin",
        "regionID": 5,
        "rural": false
    },
    {
        "areaID": 6,
        "areaName": "Gurtha Ndengin",
        "regionID": 6,
        "rural": false
    },
    {
        "areaID": 7,
        "areaName": "Mori Templa Mellon",
        "regionID": 7,
        "rural": false
    },
    {
        "areaID": 8,
        "areaName": "Rural Southern Etrand",
        "regionID": 8,
        "rural": true
    },
    {
        "areaID": 9,
        "areaName": "Rural Western Etrand",
        "regionID": 9,
        "rural": true
    },
    {
        "areaID": 10,
        "areaName": "Rural Northern Frontier",
        "regionID": 10,
        "rural": true
    },
    {
        "areaID": 11,
        "areaName": "Rural Northern Mountains",
        "regionID": 11,
        "rural": true
    },
    {
        "areaID": 12,
        "areaName": "Rural Inner Etrand",
        "regionID": 12,
        "rural": true
    },
    {
        "areaID": 13,
        "areaName": "Rural Northern Etrancoast",
        "regionID": 13,
        "rural": true
    },
    {
        "areaID": 14,
        "areaName": "Rural Southern Etrancoast",
        "regionID": 14,
        "rural": true
    },
    {
        "areaID": 15,
        "areaName": "Rural Inner Froturn",
        "regionID": 15,
        "rural": true
    },
    {
        "areaID": 16,
        "areaName": "Rural Froturnish Coastlands",
        "regionID": 16,
        "rural": true
    },
    {
        "areaID": 17,
        "areaName": "Rural Southeastern Froturn",
        "regionID": 17,
        "rural": true
    },
    {
        "areaID": 18,
        "areaName": "Rural Northeastern Froturn",
        "regionID": 18,
        "rural": true
    },
    {
        "areaID": 19,
        "areaName": "Rural Northwestern Dragoc",
        "regionID": 19,
        "rural": true
    },
    {
        "areaID": 20,
        "areaName": "Rural Southwestern Dragoc",
        "regionID": 20,
        "rural": true
    },
    {
        "areaID": 21,
        "areaName": "Rural Northeastern Dragoc",
        "regionID": 21,
        "rural": true
    },
    {
        "areaID": 22,
        "areaName": "Rural Southeastern Dragoc",
        "regionID": 22,
        "rural": true
    },
    {
        "areaID": 23,
        "areaName": "Rural Artaburro",
        "regionID": 23,
        "rural": true
    },
    {
        "areaID": 24,
        "areaName": "Rural Neressa",
        "regionID": 24,
        "rural": true
    },
    {
        "areaID": 25,
        "areaName": "Rural Keldorn",
        "regionID": 25,
        "rural": true
    },
    {
        "areaID": 26,
        "areaName": "Rural Gabyr",
        "regionID": 26,
        "rural": true
    },
    {
        "areaID": 27,
        "areaName": "Antanath",
        "regionID": 27,
        "rural": false
    },
    {
        "areaID": 28,
        "areaName": "Zorod Naugi im Pkhaur",
        "regionID": 11,
        "rural": false
    },
    {
        "areaID": 29,
        "areaName": "Zorod Koldo im Neuna",
        "regionID": 11,
        "rural": false
    },
    {
        "areaID": 30,
        "areaName": "Steelhelm",
        "regionID": 10,
        "rural": false
    },
    {
        "areaID": 31,
        "areaName": "Grandfolk",
        "regionID": 9,
        "rural": false
    },
    {
        "areaID": 32,
        "areaName": "Dracfold",
        "regionID": 12,
        "rural": false
    },
    {
        "areaID": 33,
        "areaName": "Copperport",
        "regionID": 12,
        "rural": false
    },
    {
        "areaID": 34,
        "areaName": "Talon",
        "regionID": 8,
        "rural": false
    },
    {
        "areaID": 35,
        "areaName": "Etrocast",
        "regionID": 8,
        "rural": false
    },
    {
        "areaID": 36,
        "areaName": "Yrvhaven",
        "regionID": 13,
        "rural": false
    },
    {
        "areaID": 37,
        "areaName": "Waterburcht",
        "regionID": 14,
        "rural": false
    },
    {
        "areaID": 38,
        "areaName": "Architon",
        "regionID": 18,
        "rural": false
    },
    {
        "areaID": 39,
        "areaName": "Minosa",
        "regionID": 19,
        "rural": false
    },
    {
        "areaID": 40,
        "areaName": "Helpulus",
        "regionID": 17,
        "rural": false
    },
    {
        "areaID": 41,
        "areaName": "Rodiou",
        "regionID": 20,
        "rural": false
    },
    {
        "areaID": 42,
        "areaName": "Alta Gon",
        "regionID": 23,
        "rural": false
    },
    {
        "areaID": 43,
        "areaName": "Yaara Linde",
        "regionID": 23,
        "rural": false
    },
    {
        "areaID": 44,
        "areaName": "Kelu e Taure",
        "regionID": 23,
        "rural": false
    },
    {
        "areaID": 45,
        "areaName": "Yanus",
        "regionID": 15,
        "rural": false
    },
    {
        "areaID": 46,
        "areaName": "Wohun",
        "regionID": 15,
        "rural": false
    },
    {
        "areaID": 47,
        "areaName": "Noldo Ranga",
        "regionID": 17,
        "rural": false
    },
    {
        "areaID": 48,
        "areaName": "Edhel Yaara",
        "regionID": 17,
        "rural": false
    },
    {
        "areaID": 49,
        "areaName": "Magnus Nex Urbs",
        "regionID": 25,
        "rural": false
    },
    {
        "areaID": 50,
        "areaName": "Atrum Libri",
        "regionID": 25,
        "rural": false
    },
    {
        "areaID": 51,
        "areaName": "Nex Mucro",
        "regionID": 25,
        "rural": false
    },
    {
        "areaID": 52,
        "areaName": "Gabyr City",
        "regionID": 25,
        "rural": false
    },
    {
        "areaID": 53,
        "areaName": "Neressa City",
        "regionID": 24,
        "rural": false
    }
].map(({areaID, areaName, regionID, rural}) => {
    return {
        areaName,
        areaID,
        region: regions[regionID],
        rural,
    }
});