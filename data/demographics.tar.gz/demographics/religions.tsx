export const religions = [
    {
        "religionID": 1,
        "religionName": "Atheism"
    },
    {
        "religionID": 2,
        "religionName": "Proto-Elven Religion"
    },
    {
        "religionID": 3,
        "religionName": "Church of Titanius"
    },
    {
        "religionID": 4,
        "religionName": "Cult of Nature"
    },
    {
        "religionID": 5,
        "religionName": "Orcish Religion"
    },
    {
        "religionID": 6,
        "religionName": "Fire Cult"
    },
    {
        "religionID": 7,
        "religionName": "Dark Elven Religion"
    },
    {
        "religionID": 8,
        "religionName": "Dragon Religion"
    },
    {
        "religionID": 9,
        "religionName": "Lizardman Religion"
    },
    {
        "religionID": 10,
        "religionName": "Halfling Paganism"
    },
    {
        "religionID": 11,
        "religionName": "Demonic Religion"
    },
    {
        "religionID": 12,
        "religionName": "Human Paganism"
    },
    {
        "religionID": 13,
        "religionName": "Dwarven Religion"
    },
    {
        "religionID": 14,
        "religionName": "Aeséni Shamanism"
    },
    {
        "religionID": 15,
        "religionName": "Goblin Shamanism"
    },
    {
        "religionID": 16,
        "religionName": "Ten Heavenly Principles"
    },
    {
        "religionID": 17,
        "religionName": "Shár Imperial Cult"
    },
    {
        "religionID": 18,
        "religionName": "Shár Folk Religion"
    },
    {
        "religionID": 19,
        "religionName": "Syncretism (Shár Folk Religion + Ten Heavenly Principles)"
    },
    {
        "religionID": 20,
        "religionName": "Sak Shamanism"
    },
    {
        "religionID": 21,
        "religionName": "Syncretism (Sak Shamanism + Ten Heavenly Principles)"
    },
    {
        "religionID": 22,
        "religionName": "Azisiri Paganism"
    },
    {
        "religionID": 23,
        "religionName": "Syncretism (Azisiri Paganism + Ten Heavenly Principles)"
    },
    {
        "religionID": 24,
        "religionName": "Týrýng Folk Religion"
    },
    {
        "religionID": 25,
        "religionName": "Syncretism (Týrýng Folk Religion + Ten Heavenly Principles)"
    },
    {
        "religionID": 26,
        "religionName": "Shíd Royal Cult"
    },
    {
        "religionID": 27,
        "religionName": "Shíd Fetishism"
    }
];