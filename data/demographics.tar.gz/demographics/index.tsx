import {pops} from "./pops";
import {religions} from "./religions";
import {races} from "./races";
import {occupations} from "./occupations";
import {age_groups} from "./age-groups";

export const demographics = pops.map((value) => {
    const {religionID, raceID, occupationID, agegroupID, female, quantity, areaID} = value;

    return {
        area: "unknown",
        religion: religions[religionID],
        race: races[raceID],
        occupation: occupations[occupationID],
        ageGroup: age_groups[agegroupID],
        gender: female?"female":"male",
        quantity: quantity,
    }
})