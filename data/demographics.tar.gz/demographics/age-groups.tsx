export const age_groups = [
    {
        "agegrpID": 1,
        "agegrpName": "Underage"
    },
    {
        "agegrpID": 2,
        "agegrpName": "Adult"
    },
    {
        "agegrpID": 3,
        "agegrpName": "Elderly"
    }
]