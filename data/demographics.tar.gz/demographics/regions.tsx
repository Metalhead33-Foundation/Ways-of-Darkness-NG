import {countries} from "./countries";

export const regions = [
    {
        "regionID": 1,
        "regionName": "Hro'z",
        "countryID": 9
    },
    {
        "regionID": 2,
        "regionName": "Kro'm",
        "countryID": 9
    },
    {
        "regionID": 3,
        "regionName": "Bru'k",
        "countryID": 9
    },
    {
        "regionID": 4,
        "regionName": "Pri'd",
        "countryID": 9
    },
    {
        "regionID": 5,
        "regionName": "Dhaeraow Loomin",
        "countryID": 2
    },
    {
        "regionID": 6,
        "regionName": "Gurtha Ndengin",
        "countryID": 2
    },
    {
        "regionID": 7,
        "regionName": "Mori Templa Mellon",
        "countryID": 2
    },
    {
        "regionID": 8,
        "regionName": "Southern Etrand",
        "countryID": 3
    },
    {
        "regionID": 9,
        "regionName": "Western Etrand",
        "countryID": 3
    },
    {
        "regionID": 10,
        "regionName": "Northern Frontier",
        "countryID": 3
    },
    {
        "regionID": 11,
        "regionName": "Northern Mountains",
        "countryID": 3
    },
    {
        "regionID": 12,
        "regionName": "Inner Etrand",
        "countryID": 3
    },
    {
        "regionID": 13,
        "regionName": "Northern Etrancoast",
        "countryID": 4
    },
    {
        "regionID": 14,
        "regionName": "Southern Etrancoast",
        "countryID": 4
    },
    {
        "regionID": 15,
        "regionName": "Inner Froturn",
        "countryID": 5
    },
    {
        "regionID": 16,
        "regionName": "The Froturnish Coastlands",
        "countryID": 5
    },
    {
        "regionID": 17,
        "regionName": "Southeastern Froturn",
        "countryID": 5
    },
    {
        "regionID": 18,
        "regionName": "Northeastern Froturn",
        "countryID": 5
    },
    {
        "regionID": 19,
        "regionName": "Northwestern Dragoc",
        "countryID": 6
    },
    {
        "regionID": 20,
        "regionName": "Southwestern Dragoc",
        "countryID": 6
    },
    {
        "regionID": 21,
        "regionName": "Northeastern Dragoc",
        "countryID": 6
    },
    {
        "regionID": 22,
        "regionName": "Southeastern Dragoc",
        "countryID": 6
    },
    {
        "regionID": 23,
        "regionName": "Artaburro",
        "countryID": 7
    },
    {
        "regionID": 24,
        "regionName": "Neressa",
        "countryID": 8
    },
    {
        "regionID": 25,
        "regionName": "Keldorn",
        "countryID": 10
    },
    {
        "regionID": 26,
        "regionName": "Gabyr",
        "countryID": 11
    },
    {
        "regionID": 27,
        "regionName": "Antanath",
        "countryID": 15
    }
].map(({regionID, regionName, countryID}) => {
    return {
        regionName,
        country: countries[countryID]
    }
});